
0. Please check "ParamSetting.m" carefully.

1. Make a measurement: MeasurementGen.m: F5
    1.1 Poisson Noise can be imposed.

2. Reconstruction examples
    2.1 FDK
    2.2 MLEM
    2.3 SART
    2.4 SQS (Separable quadratic surrogates, Prof. Jeffrey Fessler's algorithm)


